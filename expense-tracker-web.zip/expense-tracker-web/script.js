const form = document.getElementById("expenseForm");
const expenseList = document.getElementById("expenseList");
const totalElement = document.getElementById("total");
const countElement = document.getElementById("count");
const emptyMessage = document.getElementById("emptyMessage");
const clearBtn = document.getElementById("clearBtn");

let expenses = JSON.parse(localStorage.getItem("expenses")) || [];

function saveExpenses() {
  localStorage.setItem("expenses", JSON.stringify(expenses));
}

function renderExpenses() {
  expenseList.innerHTML = "";

  let total = 0;

  expenses.forEach((expense, index) => {
    total += Number(expense.amount);

    const row = document.createElement("tr");

    row.innerHTML = `
      <td>${expense.date}</td>
      <td>${escapeHTML(expense.description)}</td>
      <td>${escapeHTML(expense.category)}</td>
      <td>₹${Number(expense.amount).toFixed(2)}</td>
      <td>
        <button class="delete-btn" onclick="deleteExpense(${index})">Delete</button>
      </td>
    `;

    expenseList.appendChild(row);
  });

  totalElement.textContent = `₹${total.toFixed(2)}`;
  countElement.textContent = expenses.length;
  emptyMessage.style.display = expenses.length ? "none" : "block";
}

function escapeHTML(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

form.addEventListener("submit", function(event) {
  event.preventDefault();

  const expense = {
    date: document.getElementById("date").value,
    description: document.getElementById("description").value,
    category: document.getElementById("category").value,
    amount: document.getElementById("amount").value
  };

  expenses.push(expense);
  saveExpenses();
  renderExpenses();

  form.reset();
  document.getElementById("date").valueAsDate = new Date();
});

function deleteExpense(index) {
  expenses.splice(index, 1);
  saveExpenses();
  renderExpenses();
}

clearBtn.addEventListener("click", function() {
  if (expenses.length && confirm("Delete all expenses?")) {
    expenses = [];
    saveExpenses();
    renderExpenses();
  }
});

document.getElementById("date").valueAsDate = new Date();
renderExpenses();
